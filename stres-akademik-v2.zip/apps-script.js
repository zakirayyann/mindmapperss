// ================================================
// GOOGLE APPS SCRIPT - SIMPAN DATA KE GOOGLE SHEETS
// ================================================
// Cara pakai:
// 1. Buka Google Sheets baru di sheets.google.com
// 2. Klik menu Extensions > Apps Script
// 3. Hapus semua kode yang ada, lalu paste kode ini
// 4. Klik Deploy > New deployment
// 5. Pilih type: Web app
// 6. Execute as: Me
// 7. Who has access: Anyone
// 8. Klik Deploy, copy URL yang muncul
// 9. Paste URL tersebut ke file index.html
//    di bagian: const SCRIPT_URL = "PASTE_DI_SINI"

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    // Buat header jika sheet masih kosong
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["No", "Nama", "Skor", "Kategori", "Waktu"]);
      sheet.getRange(1, 1, 1, 5).setFontWeight("bold");
      sheet.setFrozenRows(1);
    }
    
    var data = JSON.parse(e.postData.contents);
    var no = sheet.getLastRow(); // nomor urut otomatis
    
    sheet.appendRow([
      no,
      data.nama,
      data.skor,
      data.kategori,
      data.waktu
    ]);
    
    return ContentService
      .createTextOutput(JSON.stringify({ status: "ok" }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: "error", message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput("Script aktif!")
    .setMimeType(ContentService.MimeType.TEXT);
}
